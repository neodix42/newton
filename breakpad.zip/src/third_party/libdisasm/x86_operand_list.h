#ifndef X86_OPERAND_LIST_H
#define X86_OPERAND_LIST_H
#include "libdis.h"


x86_op_t * x86_operand_new( x86_insn_t *insn );

#endif
