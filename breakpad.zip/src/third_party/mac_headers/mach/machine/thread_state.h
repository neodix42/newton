/*
 * This file is a stub with the bare minimum needed to make things work.
 */
#ifndef _MACH_MACHINE_THREAD_STATE_H_
#define _MACH_MACHINE_THREAD_STATE_H_

#define THREAD_STATE_MAX 1

#endif /* _MACH_MACHINE_THREAD_STATE_H_ */
