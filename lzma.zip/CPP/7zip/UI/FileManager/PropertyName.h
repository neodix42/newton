// PropertyName.h

#ifndef __PROPERTY_NAME_H
#define __PROPERTY_NAME_H

#include "../../../Common/MyString.h"

UString GetNameOfProperty(PROPID propID, const wchar_t *name);

#endif
