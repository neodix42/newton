#define IDD_OVERWRITE     3500
#define IDD_OVERWRITE_2  13500

#define IDT_OVERWRITE_HEADER          3501
#define IDT_OVERWRITE_QUESTION_BEGIN  3502
#define IDT_OVERWRITE_QUESTION_END    3503
#define IDS_FILE_SIZE                 3504

#define IDB_AUTO_RENAME               3505
#define IDB_YES_TO_ALL                 440
#define IDB_NO_TO_ALL                  441

#define IDI_OVERWRITE_OLD_FILE             100
#define IDI_OVERWRITE_NEW_FILE             101

#define IDT_OVERWRITE_OLD_FILE_SIZE_TIME   102
#define IDT_OVERWRITE_NEW_FILE_SIZE_TIME   103
